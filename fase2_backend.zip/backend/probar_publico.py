"""
probar_publico.py  -  Pruebas de las reservas públicas (Fase 2).

Crea sus propios datos por la API (emails @prueba.test, nombres "TEST ..."; se borran con
limpiar_datos.sql) y comprueba: lectura pública, validación de entradas, creación de
reservas, código privado, confirmar y cancelar con plazos, límites, aislamiento entre
negocios y que dos solicitudes simultáneas no ocupen la misma franja.
Solo usa la librería estándar de Python.

PRUEBAS FUNCIONALES  (arranca uvicorn con los límites subidos, para que las pruebas
no se bloqueen a sí mismas; en PowerShell):

    $env:VALEN_LIMITE_RESERVAS_IP = "500"
    $env:VALEN_LIMITE_CONSULTAS_IP = "5000"
    $env:VALEN_LIMITE_CODIGO_IP = "500"
    uvicorn main:app --reload
    python probar_publico.py
    python probar_publico.py --worker      # además prueba los recordatorios (lee la base de datos)

PRUEBA DE LÍMITES  (reinicia uvicorn SIN esas variables, con los límites por defecto):

    python probar_publico.py --limites
"""
import argparse
import json
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import date, timedelta
from urllib import error as urlerr
from urllib import request as urlreq

BASE = "http://127.0.0.1:8000"
CLAVE = "Clave12345"
SUF = str(int(time.time()))
SLUG = f"test-{SUF}"

E = {}          # ids y tokens que se van creando
ok = 0
fallas = []


# ---------------------------------------------------------------------------
# Utilidades
# ---------------------------------------------------------------------------
def llamar(metodo, ruta, cuerpo=None, token=None):
    """Devuelve (codigo, datos, cabeceras)."""
    datos = json.dumps(cuerpo).encode("utf-8") if cuerpo is not None else None
    peticion = urlreq.Request(BASE + ruta, data=datos, method=metodo)
    peticion.add_header("Content-Type", "application/json")

    if token:
        peticion.add_header("Authorization", f"Bearer {token}")

    try:
        with urlreq.urlopen(peticion, timeout=30) as r:
            texto, codigo, cab = r.read().decode("utf-8"), r.status, r.headers
    except urlerr.HTTPError as e:
        texto, codigo, cab = e.read().decode("utf-8"), e.code, e.headers
    except urlerr.URLError:
        sys.exit(f"No se pudo conectar con {BASE}. ¿Está corriendo uvicorn?")

    try:
        cuerpo_json = json.loads(texto) if texto else None
    except ValueError:
        cuerpo_json = texto

    return codigo, cuerpo_json, {k.lower(): v for k, v in cab.items()}


def comprobar(nombre, condicion, detalle=""):
    global ok

    if condicion:
        ok += 1
        print(f"  OK     {nombre}")
    else:
        fallas.append(nombre)
        print(f"  FALLA  {nombre}   {detalle}")


def titulo(texto):
    print(f"\n== {texto}")


def exigir(codigo, datos, que):
    if codigo != 200:
        sys.exit(f"No se pudo {que}: {codigo} {datos}")

    return datos


def telefono(n):
    return f"3{int(SUF) % 1000000:06d}{n:03d}"


def adm(metodo, ruta, cuerpo=None, clave="admin"):
    return llamar(metodo, ruta, cuerpo, E[f"tok_{clave}"])


def detalle_de(datos):
    return datos.get("detail", "") if isinstance(datos, dict) else str(datos)


# ---------------------------------------------------------------------------
# Preparación: un negocio de prueba completo (y otro para probar el aislamiento)
# ---------------------------------------------------------------------------
def registrar_y_entrar(clave, nombre):
    email = f"pub{SUF}.{clave}@prueba.test"
    c, d, _ = llamar("POST", "/usuarios", {"nombre": f"TEST {nombre}", "email": email, "password": CLAVE})
    exigir(c, d, f"registrar a {nombre}")
    c, d, _ = llamar("POST", "/auth/login", {"email": email, "password": CLAVE})
    exigir(c, d, f"entrar como {nombre}")
    E[f"email_{clave}"] = email
    E[f"tok_{clave}"] = d["access_token"]


def crear_negocio(clave, nombre):
    c, d, _ = adm("POST", "/negocios", {"nombre": nombre}, clave)
    negocio_id = exigir(c, d, "crear negocio")["id"]
    c, d, _ = adm("POST", f"/auth/negocio/{negocio_id}", None, clave)
    E[f"tok_{clave}"] = exigir(c, d, "elegir negocio")["access_token"]
    return negocio_id


CONFIG_BASE = {
    "slug": SLUG,
    "reservas_publicas_activas": True,
    "horas_confirmacion": 24,
    "cancelacion_minima_horas": 2,
    "max_reservas_activas_cliente": 3,
    "antelacion_minima_minutos": 60,
    "antelacion_maxima_dias": 60,
}


def configurar(**cambios):
    c, d, _ = adm("PUT", "/configuracion/publica", {**CONFIG_BASE, **cambios})
    return exigir(c, d, f"configurar {cambios}")


def preparar():
    titulo("Preparación: negocio con 2 empleados, 2 servicios, horario todos los días")

    for clave, nombre in (("admin", "Admin"), ("ana", "Ana"), ("bruno", "Bruno"), ("otro", "Otro")):
        registrar_y_entrar(clave, nombre)

    E["negocio"] = crear_negocio("admin", f"TEST Publico {SUF}")
    E["negocio_otro"] = crear_negocio("otro", f"TEST Otro {SUF}")

    for clave in ("ana", "bruno"):
        c, d, _ = adm("POST", "/usuarios-negocios", {"email": E[f"email_{clave}"], "rol": "EMPLEADO"})
        exigir(c, d, f"vincular a {clave}")

    c, usuarios, _ = adm("GET", "/usuarios")
    c2, vinculos, _ = adm("GET", "/usuarios-negocio")
    usuario_de = {u["email"]: u["id"] for u in usuarios}
    vinculo_de = {v["usuario_id"]: v["id"] for v in vinculos}

    for clave in ("ana", "bruno"):
        E[f"emp_{clave}"] = vinculo_de[usuario_de[E[f"email_{clave}"]]]

    for clave, minutos in (("corte", 30), ("barba", 20)):
        c, d, _ = adm("POST", "/servicios", {
            "nombre": f"TEST {clave}", "duracion_minutos": minutos, "precio": 20000,
        })
        E[f"srv_{clave}"] = exigir(c, d, f"crear servicio {clave}")["id"]

    for empleado in ("ana", "bruno"):
        for servicio in ("corte", "barba"):
            c, d, _ = adm("POST", "/empleados-servicios", {
                "servicio_id": E[f"srv_{servicio}"], "usuario_negocio_id": E[f"emp_{empleado}"],
            })
            exigir(c, d, "asignar servicio")

        for dia in range(1, 8):
            c, d, _ = adm("POST", "/horarios", {
                "usuario_negocio_id": E[f"emp_{empleado}"], "dia_semana": dia,
                "hora_inicio": "09:00", "hora_fin": "18:00", "intervalo_minutos": 30,
            })
            exigir(c, d, "crear horario")

    configurar()

    # Un servicio y un empleado del OTRO negocio, para probar que no se filtran
    c, d, _ = adm("POST", "/servicios", {"nombre": "TEST Secreto Ajeno", "duracion_minutos": 30, "precio": 1}, "otro")
    E["srv_ajeno"] = exigir(c, d, "crear servicio ajeno")["id"]
    c, d, _ = adm("GET", "/auth/me", None, "otro")
    E["emp_ajeno"] = exigir(c, d, "leer perfil ajeno")["usuario_negocio_id"]

    E["f1"] = (date.today() + timedelta(days=2)).isoformat()
    E["f2"] = (date.today() + timedelta(days=3)).isoformat()
    print(f"  negocio {E['negocio']} (enlace /{SLUG}); fechas de prueba {E['f1']} y {E['f2']}")


def cuerpo_reserva(**cambios):
    base = {
        "nombre": "TEST Cliente Uno",
        "telefono": telefono(1),
        "empleado_id": E["emp_ana"],
        "fecha": E["f1"],
        "hora_inicio": "09:00",
        "servicios": [{"servicio_id": E["srv_corte"], "cantidad": 1}],
    }
    base.update(cambios)
    return base


def reservar(**cambios):
    return llamar("POST", f"/publico/{SLUG}/reservas", cuerpo_reserva(**cambios))


def huecos(empleado, fecha, *servicios):
    consulta = "&".join(f"servicio_id={s}" for s in servicios)
    c, d, _ = llamar("GET", f"/publico/{SLUG}/disponibilidad?empleado_id={empleado}&fecha={fecha}&{consulta}")
    return [h["inicio"] for h in d["huecos"]] if c == 200 else None


# ---------------------------------------------------------------------------
# Pruebas
# ---------------------------------------------------------------------------
def prueba_lectura():
    titulo("A. Lectura pública")

    c, d, _ = llamar("GET", f"/publico/{SLUG}")
    comprobar("datos del negocio (200, con políticas)", c == 200 and "politicas" in d, f"{c} {d}")
    comprobar("no expone emails ni contraseñas", "@" not in json.dumps(d) and "password" not in json.dumps(d))

    c, d, _ = llamar("GET", f"/publico/{SLUG.upper()}")
    comprobar("el enlace no distingue mayúsculas", c == 200, f"{c}")

    c, d, _ = llamar("GET", f"/publico/{SLUG}/servicios")
    comprobar("servicios activos (2)", c == 200 and len(d) == 2, f"{c} {d}")
    comprobar("los servicios no traen ids de negocio", all("negocio_id" not in s for s in d))

    c, d, _ = llamar("GET", f"/publico/{SLUG}/empleados")
    comprobar("empleados que atienden (2: Ana y Bruno; el admin no tiene horario)", c == 200 and len(d) == 2, f"{c} {d}")
    comprobar("los empleados no exponen email", all(set(e) == {"id", "nombre", "servicio_ids"} for e in d), f"{d}")

    c, d, _ = llamar("GET", f"/publico/{SLUG}/empleados?servicio_id=999999999")
    comprobar("empleados de un servicio inexistente: lista vacía", c == 200 and d == [], f"{c} {d}")

    h = huecos(E["emp_ana"], E["f1"], E["srv_corte"])
    comprobar("disponibilidad de Ana (incluye 09:00)", h is not None and "09:00" in h, f"{h}")

    h = huecos(E["emp_ana"], E["f1"], E["srv_corte"], E["srv_barba"])
    comprobar("dos servicios suman duración", h is not None and "09:00" in h)

    titulo("A2. Lo que NO debe encontrarse")
    c, d, _ = llamar("GET", "/publico/no-existe-este-negocio")
    comprobar("enlace inexistente: 404", c == 404, f"{c}")

    c, d, _ = llamar("GET", "/publico/x'%20OR%20'1'='1")
    comprobar("enlace con inyección SQL: 404, sin error 500", c == 404, f"{c}")

    c, d, _ = llamar("GET", f"/publico/{SLUG}/disponibilidad?empleado_id={E['emp_ajeno']}&fecha={E['f1']}&servicio_id={E['srv_corte']}")
    comprobar("empleado de OTRO negocio: 404", c == 404, f"{c} {d}")

    c, d, _ = llamar("GET", f"/publico/{SLUG}/disponibilidad?empleado_id={E['emp_ana']}&fecha={E['f1']}&servicio_id={E['srv_ajeno']}")
    comprobar("servicio de OTRO negocio: 400", c == 400, f"{c} {d}")
    comprobar("...sin revelar su nombre", "Secreto" not in json.dumps(d), f"{d}")

    configurar(reservas_publicas_activas=False)
    c, d, _ = llamar("GET", f"/publico/{SLUG}")
    comprobar("reservas desactivadas: 404 (igual que si no existiera)", c == 404, f"{c}")
    configurar()

    c, d, _ = llamar("GET", f"/publico/{SLUG}/disponibilidad?empleado_id={E['emp_ana']}&fecha=2026-13-45&servicio_id={E['srv_corte']}")
    comprobar("fecha inválida: 422", c == 422, f"{c}")

    c, d, _ = llamar("GET", f"/publico/{SLUG}/disponibilidad?empleado_id={E['emp_ana']}&fecha={E['f1']}")
    comprobar("sin servicio_id: 422", c == 422, f"{c}")


def prueba_validacion():
    titulo("B. Validación de lo que manda el cliente")
    pruebas = {
        "campo extra 'estado'": {"estado": "CONFIRMADA"},
        "campo extra 'origen'": {"origen": "NEGOCIO"},
        "campo extra 'cliente_id'": {"cliente_id": 1},
        "campo extra 'hora_fin'": {"hora_fin": "10:00"},
        "teléfono inválido": {"telefono": "abc"},
        "nombre vacío": {"nombre": "   "},
        "sin servicios": {"servicios": []},
        "cantidad 99": {"servicios": [{"servicio_id": E["srv_corte"], "cantidad": 99}]},
        "servicio repetido": {"servicios": [{"servicio_id": E["srv_corte"]}, {"servicio_id": E["srv_corte"]}]},
        "observaciones de 400 caracteres": {"observaciones": "x" * 400},
        "hora inválida": {"hora_inicio": "25:99"},
    }

    for nombre, cambio in pruebas.items():
        c, d, _ = reservar(**cambio)
        comprobar(f"{nombre}: 422", c == 422, f"{c} {d}")

    c, d, _ = reservar(empleado_id=E["emp_ajeno"])
    comprobar("empleado de otro negocio: 404", c == 404, f"{c} {d}")

    c, d, _ = reservar(servicios=[{"servicio_id": E["srv_ajeno"]}])
    comprobar("servicio de otro negocio: 400 sin revelar su nombre", c == 400 and "Secreto" not in json.dumps(d), f"{c} {d}")

    c, d, _ = reservar(fecha=(date.today() - timedelta(days=1)).isoformat())
    comprobar("fecha pasada: 400", c == 400, f"{c} {d}")

    c, d, _ = reservar(fecha=(date.today() + timedelta(days=90)).isoformat())
    comprobar("más lejos que la antelación máxima del negocio: 400", c == 400, f"{c} {d}")

    c, d, _ = reservar(hora_inicio="09:10")
    comprobar("hora fuera de la cuadrícula de turnos: 409", c == 409, f"{c} {d}")

    c, d, _ = reservar(hora_inicio="20:00")
    comprobar("fuera del horario del empleado: 409", c == 409, f"{c} {d}")


def prueba_reserva():
    titulo("C. Crear una reserva")
    c, d, cab = reservar()
    comprobar("reserva válida: 200", c == 200, f"{c} {d}")

    if c != 200:
        sys.exit("Sin reserva válida no se pueden seguir las pruebas")

    E["codigo"] = d["codigo"]
    comprobar("devuelve un código de 16 caracteres", len(d["codigo"]) == 16, d["codigo"])
    comprobar("nace PENDIENTE", d["estado"] == "PENDIENTE")
    comprobar("no expone ids internos ni el teléfono", "id" not in d and telefono(1) not in json.dumps(d))
    comprobar("respuesta con Cache-Control: no-store", "no-store" in cab.get("cache-control", ""), f"{cab}")
    comprobar("hora_fin la calculó el servidor (09:30)", d["hora_fin"] == "09:30", d["hora_fin"])

    c, citas, _ = adm("GET", f"/citas?desde={E['f1']}&hasta={E['f1']}")
    propia = [x for x in citas if x["cliente"]["telefono"] == telefono(1)]
    comprobar("el panel la ve: origen CLIENTE y PENDIENTE", len(propia) == 1 and propia[0]["origen"] == "CLIENTE" and propia[0]["estado"] == "PENDIENTE", f"{propia}")
    E["cita_id"] = propia[0]["id"] if propia else None

    h = huecos(E["emp_ana"], E["f1"], E["srv_corte"])
    comprobar("la hora reservada desaparece de la disponibilidad", h is not None and "09:00" not in h and "09:30" in h, f"{h}")

    c, d, _ = reservar(nombre="TEST Otra Persona", telefono=telefono(2))
    comprobar("misma franja, otro cliente: 409", c == 409, f"{c} {d}")
    comprobar("...sin detalles de la otra cita", "cita de" not in detalle_de(d), detalle_de(d))

    c, d, _ = reservar(empleado_id=E["emp_bruno"])
    comprobar("mismo cliente a la misma hora con otro empleado: 409", c == 409, f"{c} {d}")
    comprobar("...sin revelar la hora de su otra cita", "a las" not in detalle_de(d) and "de 09" not in detalle_de(d), detalle_de(d))

    c, d, _ = reservar(nombre="NOMBRE DISTINTO", hora_inicio="11:00")
    comprobar("el mismo teléfono puede reservar otra hora", c == 200, f"{c} {d}")
    c, clientes, _ = adm("GET", "/clientes")
    uno = [x for x in clientes if x["telefono"] == telefono(1)]
    comprobar("...y no cambió el nombre del cliente existente", len(uno) == 1 and uno[0]["nombre"] == "TEST Cliente Uno", f"{uno}")


def prueba_codigo():
    titulo("D. Consultar con el código")
    c, d, cab = llamar("GET", f"/reservas-publicas/{E['codigo']}")
    comprobar("consulta con el código: 200", c == 200 and d["estado"] == "PENDIENTE", f"{c} {d}")
    comprobar("trae servicios, total y plazos", all(k in d for k in ("servicios", "total", "puede_cancelar", "cancelar_hasta", "puede_confirmar")), f"{d}")
    comprobar("no expone el teléfono del cliente", telefono(1) not in json.dumps(d))
    comprobar("Cache-Control: no-store", "no-store" in cab.get("cache-control", ""))

    bonito = "-".join(E["codigo"][i:i + 4] for i in range(0, 16, 4)).lower()
    c, d, _ = llamar("GET", f"/reservas-publicas/{bonito}")
    comprobar("acepta minúsculas y guiones", c == 200, f"{c}")

    c, d, _ = llamar("GET", "/reservas-publicas/AAAAAAAAAAAAAAAA")
    comprobar("código inexistente: 404", c == 404, f"{c}")

    c, d, _ = llamar("GET", "/reservas-publicas/corto")
    comprobar("código mal formado: 404", c == 404, f"{c}")


def prueba_confirmar_y_cancelar():
    titulo("E. Confirmar (la ventana abre N horas antes)")
    ruta = f"/reservas-publicas/{E['codigo']}"

    configurar(horas_confirmacion=1)
    c, d, _ = llamar("POST", ruta + "/confirmar")
    comprobar("ventana de 1 h: todavía no se puede confirmar (409)", c == 409 and "Todavía" in detalle_de(d), f"{c} {d}")

    configurar(horas_confirmacion=168)
    c, d, _ = llamar("POST", ruta + "/confirmar")
    comprobar("ventana de 7 días abierta: confirma (200)", c == 200 and d["estado"] == "CONFIRMADA", f"{c} {d}")

    c, d, _ = llamar("POST", ruta + "/confirmar")
    comprobar("confirmar otra vez es inofensivo (200)", c == 200 and d["estado"] == "CONFIRMADA", f"{c} {d}")

    c, citas, _ = adm("GET", f"/citas?desde={E['f1']}&hasta={E['f1']}")
    propia = [x for x in citas if x["id"] == E["cita_id"]]
    comprobar("el panel la ve CONFIRMADA", propia and propia[0]["estado"] == "CONFIRMADA", f"{propia}")

    titulo("F. Cancelar (con plazo)")
    configurar(horas_confirmacion=24, cancelacion_minima_horas=168)
    c, d, _ = llamar("POST", ruta + "/cancelar")
    comprobar("plazo de 7 días ya vencido: 409", c == 409 and "Ya no puedes cancelar" in detalle_de(d), f"{c} {d}")

    configurar(cancelacion_minima_horas=0)
    c, d, _ = llamar("POST", ruta + "/cancelar")
    comprobar("dentro del plazo: cancela (200)", c == 200 and d["estado"] == "CANCELADA", f"{c} {d}")

    c, d, _ = llamar("POST", ruta + "/cancelar")
    comprobar("cancelar otra vez es inofensivo (200)", c == 200 and d["estado"] == "CANCELADA")

    c, d, _ = llamar("POST", ruta + "/confirmar")
    comprobar("una reserva cancelada no se puede confirmar (409)", c == 409, f"{c} {d}")

    h = huecos(E["emp_ana"], E["f1"], E["srv_corte"])
    comprobar("al cancelar, la hora queda libre otra vez", h is not None and "09:00" in h, f"{h}")
    configurar()


def prueba_limite_por_cliente():
    titulo("G. Máximo de reservas activas por cliente")
    configurar(max_reservas_activas_cliente=1)

    c, d, _ = reservar(nombre="TEST Cliente Tres", telefono=telefono(3), empleado_id=E["emp_bruno"], hora_inicio="09:00")
    comprobar("primera reserva: 200", c == 200, f"{c} {d}")

    c, d, _ = reservar(nombre="TEST Cliente Tres", telefono=telefono(3), empleado_id=E["emp_bruno"], hora_inicio="10:00")
    comprobar("segunda con el máximo en 1: 409", c == 409 and "máximo" in detalle_de(d), f"{c} {d}")

    configurar()


def prueba_concurrencia():
    titulo("H. Solicitudes simultáneas")

    def disparar(cuerpos):
        barrera = threading.Barrier(len(cuerpos))

        def una(cuerpo):
            barrera.wait()
            return llamar("POST", f"/publico/{SLUG}/reservas", cuerpo)[0]

        with ThreadPoolExecutor(max_workers=len(cuerpos)) as pool:
            return list(pool.map(una, cuerpos))

    cuerpos = [
        cuerpo_reserva(nombre=f"TEST Concurrente {i}", telefono=telefono(10 + i),
                       empleado_id=E["emp_bruno"], fecha=E["f2"], hora_inicio="09:00")
        for i in range(8)
    ]
    codigos = disparar(cuerpos)
    comprobar("8 clientes, misma hora, mismo empleado: solo 1 gana", codigos.count(200) == 1, f"{codigos}")
    comprobar("los demás reciben 409 (ningún 500)", codigos.count(409) == 7, f"{codigos}")

    cuerpos = [
        cuerpo_reserva(nombre="TEST Dividido", telefono=telefono(30), empleado_id=E[f"emp_{e}"],
                       fecha=E["f2"], hora_inicio="14:00")
        for e in ("ana", "bruno")
    ]
    codigos = disparar(cuerpos)
    comprobar("1 cliente pide la misma hora con 2 empleados: solo 1 gana", codigos.count(200) == 1, f"{codigos}")
    comprobar("...y ninguno termina en error 500", all(c < 500 for c in codigos), f"{codigos}")


def prueba_worker():
    titulo("I. Recordatorios de confirmación (worker)")

    try:
        import notificaciones
        from database import SessionLocal
        from models import Notificacion
        from sqlalchemy import select
    except Exception as e:
        print(f"  (saltada: no se pudo importar el proyecto desde esta carpeta: {e})")
        return

    configurar(horas_confirmacion=168)

    c, d, _ = reservar(nombre="TEST Recordar", telefono=telefono(40), empleado_id=E["emp_ana"], fecha=E["f2"], hora_inicio="15:00")
    exigir(c, d, "crear la reserva del worker")
    c, d, _ = reservar(nombre="TEST Ya Confirmada", telefono=telefono(41), empleado_id=E["emp_ana"], fecha=E["f2"], hora_inicio="16:00")
    exigir(c, d, "crear la segunda reserva del worker")

    c, citas, _ = adm("GET", f"/citas?desde={E['f2']}&hasta={E['f2']}")
    id_a = next(x["id"] for x in citas if x["cliente"]["telefono"] == telefono(40))
    id_b = next(x["id"] for x in citas if x["cliente"]["telefono"] == telefono(41))

    c, d, _ = adm("PATCH", f"/citas/{id_b}/confirmar")
    comprobar("el negocio confirma una de ellas desde el panel", c == 200, f"{c} {d}")

    db = SessionLocal()

    try:
        proveedor = notificaciones.ProveedorConsola()
        notificaciones.programar_confirmaciones(db)
        notificaciones.enviar_pendientes(db, proveedor)

        def filas(cita_id):
            return db.execute(select(Notificacion).where(Notificacion.cita_id == cita_id)).scalars().all()

        a = filas(id_a)
        comprobar("la pendiente genera 1 notificación ENVIADA", len(a) == 1 and a[0].estado == "ENVIADA", f"{[(n.estado, n.ultimo_error) for n in a]}")
        comprobar("la ya confirmada no genera ninguna", filas(id_b) == [])

        notificaciones.programar_confirmaciones(db)
        notificaciones.enviar_pendientes(db, proveedor)
        comprobar("otra pasada no duplica el mensaje", len(filas(id_a)) == 1)
    finally:
        db.close()

    configurar()


def prueba_limites():
    titulo("L. Límites antiabuso (con los límites por defecto)")

    codigos = [llamar("GET", "/reservas-publicas/AAAAAAAAAAAAAAAA")[0] for _ in range(12)]
    comprobar("10 códigos inexistentes seguidos: 404", codigos[:10] == [404] * 10, f"{codigos}")
    comprobar("el 11.º ya recibe 429", codigos[10] == 429 and codigos[11] == 429, f"{codigos}")

    c, d, cab = llamar("GET", "/reservas-publicas/AAAAAAAAAAAAAAAA")
    comprobar("el 429 trae Retry-After", "retry-after" in cab, f"{cab}")

    cuerpo = {
        "nombre": "TEST Bot", "telefono": telefono(99), "empleado_id": 1, "fecha": "2030-01-01",
        "hora_inicio": "09:00", "servicios": [{"servicio_id": 1}],
    }
    codigos = [llamar("POST", "/publico/no-existe-este-negocio/reservas", cuerpo)[0] for _ in range(12)]
    comprobar("10 reservas por IP en 10 min; la 11.ª recibe 429", codigos[:10] == [404] * 10 and codigos[10] == 429, f"{codigos}")


# ---------------------------------------------------------------------------
def main():
    global BASE

    parser = argparse.ArgumentParser()
    parser.add_argument("--url", default=BASE)
    parser.add_argument("--worker", action="store_true", help="prueba también los recordatorios (lee la base de datos)")
    parser.add_argument("--limites", action="store_true", help="SOLO la prueba de límites (servidor con límites por defecto)")
    argumentos = parser.parse_args()
    BASE = argumentos.url.rstrip("/")

    if argumentos.limites:
        prueba_limites()
    else:
        preparar()
        prueba_lectura()
        prueba_validacion()
        prueba_reserva()
        prueba_codigo()
        prueba_confirmar_y_cancelar()
        prueba_limite_por_cliente()
        prueba_concurrencia()

        if argumentos.worker:
            prueba_worker()

    print(f"\n{ok} comprobaciones correctas, {len(fallas)} con falla")

    for f in fallas:
        print(f"  - {f}")

    sys.exit(1 if fallas else 0)


if __name__ == "__main__":
    main()
