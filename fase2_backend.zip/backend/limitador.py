"""
Límites antiabuso para los endpoints públicos (los que no piden sesión).

Es un limitador en MEMORIA del proceso: sirve para un solo proceso de uvicorn y se
reinicia al reiniciar el servidor. Si más adelante corres varios procesos o varios
servidores, cada uno cuenta por separado; ahí conviene mover estos contadores a
Redis o aplicar el límite en el proxy (nginx, Cloudflare). La interfaz de este
archivo es pequeña a propósito para poder cambiarla sin tocar los endpoints.

Los límites se pueden ajustar con variables de entorno (ver publico.py).
"""
import os
import threading
import time
from collections import defaultdict, deque

from fastapi import HTTPException, Request


class Limitador:
    def __init__(self):
        self._eventos = defaultdict(deque)
        self._lock = threading.Lock()
        self._ultima_limpieza = time.monotonic()

    def _limpiar(self, ahora: float):
        # Cada 5 minutos descarta claves sin actividad en la última hora
        if ahora - self._ultima_limpieza < 300:
            return

        self._ultima_limpieza = ahora

        for clave in [k for k, d in self._eventos.items() if not d or ahora - d[-1] > 3600]:
            del self._eventos[clave]

    def _espera(self, eventos: deque, ahora: float, maximo: int, ventana: int) -> int:
        while eventos and ahora - eventos[0] > ventana:
            eventos.popleft()

        if len(eventos) >= maximo:
            return max(1, int(ventana - (ahora - eventos[0])) + 1)

        return 0

    def intentar(self, clave: str, maximo: int, ventana_segundos: int) -> int:
        """Cuenta un evento. Devuelve 0 si se permite, o los segundos de espera si no."""
        ahora = time.monotonic()

        with self._lock:
            self._limpiar(ahora)
            eventos = self._eventos[clave]
            espera = self._espera(eventos, ahora, maximo, ventana_segundos)

            if espera == 0:
                eventos.append(ahora)

            return espera

    def espera(self, clave: str, maximo: int, ventana_segundos: int) -> int:
        """Segundos de espera si la clave ya llegó al máximo; NO cuenta un evento."""
        ahora = time.monotonic()

        with self._lock:
            if clave not in self._eventos:
                return 0

            return self._espera(self._eventos[clave], ahora, maximo, ventana_segundos)

    def registrar(self, clave: str):
        """Cuenta un evento sin comprobar nada (para registrar fallos)."""
        with self._lock:
            self._eventos[clave].append(time.monotonic())


limitador = Limitador()


def ip_cliente(request: Request) -> str:
    """
    IP de quien llama. Detrás de UN proxy de confianza (nginx, Cloudflare...) define
    VALEN_CONFIAR_X_FORWARDED_FOR=1 y se usa la última IP que añadió el proxy.
    Sin proxy NO lo actives: cualquiera podría falsificar esa cabecera.
    """
    if os.getenv("VALEN_CONFIAR_X_FORWARDED_FOR") == "1":
        cabecera = request.headers.get("x-forwarded-for", "")
        ultima = cabecera.split(",")[-1].strip()

        if ultima:
            return ultima

    return request.client.host if request.client else "desconocida"


def _demasiadas(espera: int) -> HTTPException:
    return HTTPException(
        status_code=429,
        detail="Demasiadas solicitudes. Intenta de nuevo en unos minutos",
        headers={"Retry-After": str(espera)},
    )


def exigir_limite(request: Request, accion: str, maximo: int, ventana_segundos: int):
    """Máximo `maximo` llamadas de `accion` por IP en `ventana_segundos`; si no, 429."""
    espera = limitador.intentar(f"{accion}:{ip_cliente(request)}", maximo, ventana_segundos)

    if espera:
        raise _demasiadas(espera)


def exigir_sin_fallos(request: Request, accion: str, maximo: int, ventana_segundos: int):
    """Si esta IP ya acumuló `maximo` fallos de `accion` en la ventana, responde 429."""
    espera = limitador.espera(f"fallo_{accion}:{ip_cliente(request)}", maximo, ventana_segundos)

    if espera:
        raise _demasiadas(espera)


def registrar_fallo(request: Request, accion: str):
    limitador.registrar(f"fallo_{accion}:{ip_cliente(request)}")
