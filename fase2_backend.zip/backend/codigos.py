"""
Código privado de una reserva y enlaces que se le envían al cliente.

El código es lo único que identifica la reserva para quien NO tiene cuenta, así que
se genera con `secrets` (no con random) y es largo: 16 caracteres de un alfabeto de
30 símbolos (~78 bits). Sin letras ni números que se confunden (0/O, 1/I/L, U).

Enlaces (la página pública del front debe tener estas dos rutas):
    {VALEN_URL_RESERVAS}/{slug}             -> página para reservar de un negocio
    {VALEN_URL_RESERVAS}/reserva/{codigo}   -> ver, confirmar o cancelar una reserva
"""
import os
import re
import secrets

ALFABETO = "ABCDEFGHJKMNPQRSTVWXYZ23456789"
LARGO = 16
_PATRON = re.compile(rf"[{ALFABETO}]{{{LARGO}}}")


def generar_codigo() -> str:
    return "".join(secrets.choice(ALFABETO) for _ in range(LARGO))


def normalizar_codigo(texto: str | None) -> str | None:
    """'abcd-efgh jkmn-pqrs' -> 'ABCDEFGHJKMNPQRS'. None si no tiene la forma de un código."""
    limpio = re.sub(r"[\s\-]", "", texto or "").upper()
    return limpio if _PATRON.fullmatch(limpio) else None


def _base_url() -> str:
    return os.getenv("VALEN_URL_RESERVAS", "http://localhost:5173").rstrip("/")


def enlace_negocio(slug: str) -> str:
    return f"{_base_url()}/{slug}"


def enlace_reserva(codigo: str) -> str:
    return f"{_base_url()}/reserva/{codigo}"
