"""Reservas públicas: enlace y políticas del negocio, código de reserva, notificaciones

Negocio:
  slug                          enlace público (único). NULL = sin página pública.
  reservas_publicas_activas     interruptor; por defecto apagado.
  horas_confirmacion            horas antes de la cita en que se pide confirmar por
                                WhatsApp. NULL (por defecto) = el negocio no usa recordatorios.
  cancelacion_minima_horas      plazo para que el cliente cancele solo (por defecto 2).
  max_reservas_activas_cliente  tope de reservas vivas por cliente (por defecto 3).
  antelacion_minima_minutos     por defecto 60  (antes eran constantes en reglas.py).
  antelacion_maxima_dias        por defecto 60.
Cita:
  codigo_publico                código privado para consultar/confirmar/cancelar sin cuenta.
Notificacion (tabla nueva):
  cola de mensajes salientes; UNIQUE (cita_id, tipo) evita pedir dos veces la misma confirmación.

Todo lleva IF NOT EXISTS para poder aplicarla aunque algo ya exista.

Revision ID: 0003
Revises: 0002
Create Date: 2026-11-01
"""
from alembic import op

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("ALTER TABLE negocio ADD COLUMN IF NOT EXISTS slug VARCHAR(40)")
    op.execute("ALTER TABLE negocio ADD COLUMN IF NOT EXISTS reservas_publicas_activas BOOLEAN NOT NULL DEFAULT FALSE")
    op.execute("ALTER TABLE negocio ADD COLUMN IF NOT EXISTS horas_confirmacion INTEGER")
    op.execute("ALTER TABLE negocio ADD COLUMN IF NOT EXISTS cancelacion_minima_horas INTEGER NOT NULL DEFAULT 2")
    op.execute("ALTER TABLE negocio ADD COLUMN IF NOT EXISTS max_reservas_activas_cliente INTEGER NOT NULL DEFAULT 3")
    op.execute("ALTER TABLE negocio ADD COLUMN IF NOT EXISTS antelacion_minima_minutos INTEGER NOT NULL DEFAULT 60")
    op.execute("ALTER TABLE negocio ADD COLUMN IF NOT EXISTS antelacion_maxima_dias INTEGER NOT NULL DEFAULT 60")
    op.execute("CREATE UNIQUE INDEX IF NOT EXISTS ux_negocio_slug ON negocio (slug)")

    op.execute("ALTER TABLE cita ADD COLUMN IF NOT EXISTS codigo_publico VARCHAR(20)")
    op.execute("CREATE UNIQUE INDEX IF NOT EXISTS ux_cita_codigo_publico ON cita (codigo_publico)")

    op.execute(
        """
        CREATE TABLE IF NOT EXISTS notificacion (
            id               BIGSERIAL PRIMARY KEY,
            negocio_id       BIGINT      NOT NULL REFERENCES negocio (id),
            cita_id          BIGINT      NOT NULL REFERENCES cita (id) ON DELETE CASCADE,
            tipo             VARCHAR(30) NOT NULL,
            canal            VARCHAR(20) NOT NULL DEFAULT 'WHATSAPP',
            estado           VARCHAR(20) NOT NULL DEFAULT 'PENDIENTE',
            intentos         INTEGER     NOT NULL DEFAULT 0,
            ultimo_error     TEXT,
            proveedor_id     VARCHAR(100),
            proximo_intento  TIMESTAMP   NOT NULL DEFAULT now(),
            fecha_creacion   TIMESTAMP   DEFAULT now(),
            fecha_envio      TIMESTAMP,
            CONSTRAINT chk_notificacion_estado
                CHECK (estado IN ('PENDIENTE', 'ENVIADA', 'FALLIDA', 'OMITIDA')),
            CONSTRAINT ux_notificacion_cita_tipo UNIQUE (cita_id, tipo)
        )
        """
    )
    op.execute(
        "CREATE INDEX IF NOT EXISTS ix_notificacion_pendientes ON notificacion (estado, proximo_intento)"
    )


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS notificacion")

    op.execute("DROP INDEX IF EXISTS ux_cita_codigo_publico")
    op.execute("ALTER TABLE cita DROP COLUMN IF EXISTS codigo_publico")

    op.execute("DROP INDEX IF EXISTS ux_negocio_slug")

    for columna in (
        "antelacion_maxima_dias",
        "antelacion_minima_minutos",
        "max_reservas_activas_cliente",
        "cancelacion_minima_horas",
        "horas_confirmacion",
        "reservas_publicas_activas",
        "slug",
    ):
        op.execute(f"ALTER TABLE negocio DROP COLUMN IF EXISTS {columna}")
