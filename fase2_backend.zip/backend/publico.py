"""
Reservas públicas (sin sesión de usuario) y la configuración que las controla.

PÁGINA PÚBLICA DE UN NEGOCIO  (la identifica el "slug", ej. /publico/barberia-valen)
  GET  /publico/{slug}                  datos públicos y políticas del negocio
  GET  /publico/{slug}/servicios        servicios activos
  GET  /publico/{slug}/empleados        empleados que atienden (?servicio_id=1&servicio_id=2)
  GET  /publico/{slug}/disponibilidad   horas libres (?empleado_id=&fecha=&servicio_id=)
  POST /publico/{slug}/reservas         crea una reserva PENDIENTE y devuelve su código

GESTIÓN CON EL CÓDIGO PRIVADO DE LA RESERVA
  GET  /reservas-publicas/{codigo}              ver la reserva
  POST /reservas-publicas/{codigo}/confirmar    el cliente la confirma
  POST /reservas-publicas/{codigo}/cancelar     el cliente la cancela (hasta el plazo del negocio)

CONFIGURACIÓN (solo ADMIN, con sesión)
  GET/PUT /configuracion/publica        enlace, activar reservas, plazos y límites

Reglas que protegen este módulo (todo lo que llega sin sesión es hostil por defecto):
  * Solo se aceptan los campos del esquema (extra="forbid"): el cliente no puede mandar
    estado, origen, precios, hora de fin ni id de cliente.
  * Las reservas siempre nacen PENDIENTE y con origen CLIENTE; el servidor calcula precios,
    duración y hora de fin y comprueba disponibilidad con las mismas reglas del panel.
  * Un negocio sin enlace o con las reservas desactivadas responde 404, igual que uno que no existe.
  * Los errores no revelan datos de otros: ni nombres de servicios de otro negocio, ni las
    horas de otras citas, ni motivos de las pausas.
  * Límites por IP, por teléfono y por negocio (ver LIMITE_* abajo) y 429 al superarlos.
  * El código de una reserva (78 bits) no se puede adivinar; además, los fallos al consultarlo
    se limitan por IP.
  * Las respuestas con código llevan Cache-Control: no-store.
"""
import os
import re
from datetime import date, datetime, timedelta
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, Request, Response
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError

import schemas
from agenda import calcular_huecos
from auth import Contexto, solo_admin
from codigos import enlace_negocio, enlace_reserva, generar_codigo, normalizar_codigo
from database import SessionLocal
from limitador import exigir_limite, exigir_sin_fallos, registrar_fallo
from models import (
    Cita,
    Cliente,
    EmpleadoServicio,
    Horario,
    Negocio,
    Servicio,
    ServicioDeCita,
    Usuario,
    UsuarioNegocio,
)
from reglas import (
    calcular_hora_fin,
    citas_futuras_activas,
    duracion_servicios_minutos,
    exigir_empleado_valido,
    exigir_servicio_para_empleado,
    obtener_o_404,
    validar_antelacion,
    validar_cliente_sin_solape,
    validar_disponibilidad,
    validar_no_en_el_pasado,
)

router = APIRouter()


# ---------------------------------------------------------------------------
# Límites (ajustables con variables de entorno)
# ---------------------------------------------------------------------------
def _entero_env(nombre: str, defecto: int) -> int:
    try:
        return int(os.getenv(nombre, defecto))
    except ValueError:
        return defecto


VENTANA_SEGUNDOS = 600  # 10 minutos
LIMITE_RESERVAS_IP = _entero_env("VALEN_LIMITE_RESERVAS_IP", 10)       # reservas por IP / 10 min
LIMITE_CONSULTAS_IP = _entero_env("VALEN_LIMITE_CONSULTAS_IP", 120)    # consultas por IP / 10 min
LIMITE_CODIGO_IP = _entero_env("VALEN_LIMITE_CODIGO_IP", 60)           # usos de un código por IP / 10 min
LIMITE_FALLOS_CODIGO_IP = 10                                           # códigos inexistentes por IP / 10 min
LIMITE_RESERVAS_NEGOCIO_HORA = _entero_env("VALEN_LIMITE_RESERVAS_NEGOCIO_HORA", 60)
LIMITE_RESERVAS_CLIENTE_HORA = 5

ESTADO_TEXTO = {
    "PENDIENTE": "pendiente de confirmación",
    "CONFIRMADA": "confirmada",
    "CANCELADA": "cancelada",
    "COMPLETADA": "completada",
    "NO_ASISTIO": "marcada como no asistida",
}

_PATRON_SLUG = re.compile(r"[a-z0-9]+(-[a-z0-9]+)*")


# ---------------------------------------------------------------------------
# Utilidades
# ---------------------------------------------------------------------------
def _sin_cache(response: Response):
    response.headers["Cache-Control"] = "no-store"


def _negocio_publico(db, slug: str):
    """El negocio de ese enlace, solo si tiene las reservas públicas activas."""
    slug = slug.strip().lower()

    if len(slug) > 40 or not _PATRON_SLUG.fullmatch(slug):
        raise HTTPException(status_code=404, detail="Negocio no encontrado")

    negocio = db.execute(select(Negocio).where(Negocio.slug == slug)).scalars().first()

    if negocio is None or not negocio.reservas_publicas_activas:
        raise HTTPException(status_code=404, detail="Negocio no encontrado")

    return negocio


def _empleado_publico(db, negocio, empleado_id: int, bloquear: bool = False):
    # Un solo mensaje: no se distingue "no existe" de "es de otro negocio" ni de "inactivo"
    try:
        return exigir_empleado_valido(db, empleado_id, negocio.id, bloquear=bloquear)
    except HTTPException:
        raise HTTPException(status_code=404, detail="Empleado no disponible")


def _servicio_publico(db, servicio_id: int, empleado):
    # Los mensajes originales incluyen el nombre del servicio, que podría ser de otro negocio
    try:
        return exigir_servicio_para_empleado(db, servicio_id, empleado)
    except HTTPException:
        raise HTTPException(
            status_code=400,
            detail="Uno de los servicios no está disponible con ese empleado",
        )


def _confirmar_desde(negocio, inicio: datetime) -> datetime | None:
    """Desde cuándo puede confirmar el cliente. None = en cualquier momento."""
    if negocio.horas_confirmacion is None:
        return None

    return inicio - timedelta(hours=negocio.horas_confirmacion)


def _detalle_reserva(cita, negocio, ahora: datetime) -> dict:
    """Lo que ve quien tiene el código. Sin datos de contacto del cliente ni ids internos."""
    inicio = datetime.combine(cita.fecha, cita.hora_inicio)
    confirmar_desde = _confirmar_desde(negocio, inicio)
    cancelar_hasta = inicio - timedelta(hours=negocio.cancelacion_minima_horas)
    activa = cita.estado in ("PENDIENTE", "CONFIRMADA") and inicio > ahora

    total = sum(s.precio_unitario * s.cantidad for s in cita.servicios)
    empleado = cita.usuario_negocio.usuario.nombre if cita.usuario_negocio else None
    cliente = cita.cliente.nombre.split()[0] if cita.cliente and cita.cliente.nombre.strip() else None

    return {
        "codigo": cita.codigo_publico,
        "estado": cita.estado,
        "negocio": {
            "nombre": negocio.nombre,
            "telefono": negocio.telefono,
            "direccion": negocio.direccion,
        },
        "cliente": cliente,
        "empleado": empleado,
        "fecha": cita.fecha.isoformat(),
        "hora_inicio": cita.hora_inicio.strftime("%H:%M"),
        "hora_fin": cita.hora_fin.strftime("%H:%M"),
        "inicio": inicio.isoformat(),
        "servicios": [
            {
                "nombre": s.servicio.nombre if s.servicio else None,
                "cantidad": s.cantidad,
                "duracion_minutos": s.duracion_minutos,
                "precio_unitario": float(s.precio_unitario),
            }
            for s in cita.servicios
        ],
        "total": float(total),
        "puede_confirmar": (
            cita.estado == "PENDIENTE"
            and inicio > ahora
            and (confirmar_desde is None or ahora >= confirmar_desde)
        ),
        "confirmar_desde": confirmar_desde.isoformat() if confirmar_desde else None,
        "puede_cancelar": activa and ahora <= cancelar_hasta,
        "cancelar_hasta": cancelar_hasta.isoformat(),
    }


# ---------------------------------------------------------------------------
# Página pública del negocio
# ---------------------------------------------------------------------------
@router.get("/publico/{slug}")
def obtener_negocio_publico(slug: str, request: Request):
    exigir_limite(request, "consulta", LIMITE_CONSULTAS_IP, VENTANA_SEGUNDOS)
    db = SessionLocal()

    try:
        negocio = _negocio_publico(db, slug)

        return {
            "nombre": negocio.nombre,
            "telefono": negocio.telefono,
            "direccion": negocio.direccion,
            "politicas": {
                "horas_confirmacion": negocio.horas_confirmacion,
                "cancelacion_minima_horas": negocio.cancelacion_minima_horas,
                "max_reservas_activas_cliente": negocio.max_reservas_activas_cliente,
                "antelacion_minima_minutos": negocio.antelacion_minima_minutos,
                "antelacion_maxima_dias": negocio.antelacion_maxima_dias,
            },
        }

    finally:
        db.close()


@router.get("/publico/{slug}/servicios")
def obtener_servicios_publicos(slug: str, request: Request):
    exigir_limite(request, "consulta", LIMITE_CONSULTAS_IP, VENTANA_SEGUNDOS)
    db = SessionLocal()

    try:
        negocio = _negocio_publico(db, slug)

        servicios = db.execute(
            select(Servicio)
            .where(Servicio.negocio_id == negocio.id, Servicio.activo == True)
            .order_by(Servicio.nombre)
        ).scalars().all()

        return [
            {
                "id": s.id,
                "nombre": s.nombre,
                "descripcion": s.descripcion,
                "duracion_minutos": s.duracion_minutos,
                "precio": float(s.precio),
            }
            for s in servicios
        ]

    finally:
        db.close()


@router.get("/publico/{slug}/empleados")
def obtener_empleados_publicos(
    slug: str,
    request: Request,
    servicio_id: Annotated[list[int] | None, Query(max_length=5)] = None,
):
    """Quién atiende. Con ?servicio_id=... solo quienes atienden TODOS esos servicios."""
    exigir_limite(request, "consulta", LIMITE_CONSULTAS_IP, VENTANA_SEGUNDOS)
    db = SessionLocal()

    try:
        negocio = _negocio_publico(db, slug)

        empleados = db.execute(
            select(UsuarioNegocio.id, Usuario.nombre)
            .join(Usuario, Usuario.id == UsuarioNegocio.usuario_id)
            .where(
                UsuarioNegocio.negocio_id == negocio.id,
                UsuarioNegocio.activo == True,
            )
            .order_by(Usuario.nombre)
        ).all()

        ids = [e.id for e in empleados]

        asignaciones = db.execute(
            select(EmpleadoServicio.usuario_negocio_id, EmpleadoServicio.servicio_id)
            .join(Servicio, Servicio.id == EmpleadoServicio.servicio_id)
            .where(
                Servicio.negocio_id == negocio.id,
                Servicio.activo == True,
                EmpleadoServicio.usuario_negocio_id.in_(ids),
            )
        ).all()

        con_horario = set(
            db.execute(
                select(Horario.usuario_negocio_id)
                .where(Horario.activo == True, Horario.usuario_negocio_id.in_(ids))
                .distinct()
            ).scalars().all()
        )

        servicios_de = {}

        for a in asignaciones:
            servicios_de.setdefault(a.usuario_negocio_id, set()).add(a.servicio_id)

        pedidos = set(servicio_id or [])
        resultado = []

        for e in empleados:
            atiende = servicios_de.get(e.id, set())

            # Sin servicios o sin horario no se puede reservar con esa persona
            if e.id not in con_horario or not atiende:
                continue

            if pedidos and not pedidos <= atiende:
                continue

            resultado.append({"id": e.id, "nombre": e.nombre, "servicio_ids": sorted(atiende)})

        return resultado

    finally:
        db.close()


@router.get("/publico/{slug}/disponibilidad")
def obtener_disponibilidad_publica(
    slug: str,
    request: Request,
    empleado_id: int,
    fecha: date,
    servicio_id: Annotated[list[int], Query(min_length=1, max_length=5)],
):
    """Horas libres de un empleado, con la antelación mínima y máxima del negocio."""
    exigir_limite(request, "consulta", LIMITE_CONSULTAS_IP, VENTANA_SEGUNDOS)

    if len(set(servicio_id)) != len(servicio_id):
        raise HTTPException(status_code=400, detail="No repitas servicios en la consulta")

    db = SessionLocal()

    try:
        negocio = _negocio_publico(db, slug)
        empleado = _empleado_publico(db, negocio, empleado_id)
        servicios = [_servicio_publico(db, sid, empleado) for sid in servicio_id]

        duracion = sum(s.duracion_minutos for s in servicios)
        hoy = date.today()
        huecos = []

        if hoy <= fecha <= hoy + timedelta(days=negocio.antelacion_maxima_dias):
            huecos = calcular_huecos(
                db, empleado.id, fecha, duracion,
                aplicar_antelacion=True,
                antelacion_minima_minutos=negocio.antelacion_minima_minutos,
                antelacion_maxima_dias=negocio.antelacion_maxima_dias,
            )

        return {
            "fecha": fecha,
            "empleado_id": empleado.id,
            "duracion_minutos": duracion,
            "huecos": [
                {
                    "inicio": h.strftime("%H:%M"),
                    "fin": (datetime.combine(fecha, h) + timedelta(minutes=duracion)).strftime("%H:%M"),
                }
                for h in huecos
            ],
        }

    finally:
        db.close()


# ---------------------------------------------------------------------------
# Crear una reserva
# ---------------------------------------------------------------------------
def _cliente_para_reserva(db, negocio, nombre: str, telefono: str):
    """
    El cliente de ese teléfono en ese negocio; si no existe se crea. Un cliente que ya
    existe NO se modifica: quien reserva sin sesión no puede cambiar el nombre de nadie.
    """
    consulta = select(Cliente).where(
        Cliente.negocio_id == negocio.id, Cliente.telefono == telefono
    )
    cliente = db.execute(consulta).scalars().first()

    if cliente is None:
        cliente = Cliente(negocio_id=negocio.id, nombre=nombre, telefono=telefono)

        try:
            with db.begin_nested():
                db.add(cliente)
                db.flush()
        except IntegrityError:
            # Otra petición creó al mismo cliente justo antes: se usa ese
            cliente = db.execute(consulta).scalars().first()

            if cliente is None:
                raise HTTPException(
                    status_code=409, detail="No se pudo registrar la reserva, intenta de nuevo"
                )

    if not cliente.activo:
        raise HTTPException(
            status_code=409,
            detail=(
                "No podemos registrar tu reserva por este medio. "
                f"Comunícate con {negocio.nombre}"
            ),
        )

    return cliente


def _genericar_409(mensaje: str, funcion, *args, **kwargs):
    """Ejecuta una validación y, si responde 409, devuelve un mensaje sin detalles internos."""
    try:
        funcion(*args, **kwargs)
    except HTTPException as e:
        if e.status_code == 409:
            raise HTTPException(status_code=409, detail=mensaje)
        raise


@router.post("/publico/{slug}/reservas")
def crear_reserva_publica(
    slug: str, datos: schemas.ReservaPublicaCrear, request: Request, response: Response
):
    exigir_limite(request, "reserva", LIMITE_RESERVAS_IP, VENTANA_SEGUNDOS)
    _sin_cache(response)

    db = SessionLocal()

    try:
        negocio = _negocio_publico(db, slug)
        ahora = datetime.now()
        hace_una_hora = ahora - timedelta(hours=1)

        # Tope por negocio: frena a quien rota IPs y teléfonos para llenar la agenda
        del_negocio = db.execute(
            select(func.count()).select_from(Cita).where(
                Cita.negocio_id == negocio.id,
                Cita.origen == "CLIENTE",
                Cita.fecha_creacion >= hace_una_hora,
            )
        ).scalar()

        if del_negocio >= LIMITE_RESERVAS_NEGOCIO_HORA:
            raise HTTPException(
                status_code=429,
                detail="Hay muchas reservas en este momento. Intenta de nuevo en un rato",
                headers={"Retry-After": "600"},
            )

        # Se bloquea al empleado: dos reservas simultáneas para la misma persona se
        # atienden una tras otra, así no se pisan (igual que en POST /citas).
        empleado = _empleado_publico(db, negocio, datos.empleado_id, bloquear=True)

        validar_no_en_el_pasado(datos.fecha, datos.hora_inicio)
        validar_antelacion(
            datos.fecha, datos.hora_inicio, "CLIENTE",
            minima_minutos=negocio.antelacion_minima_minutos,
            maxima_dias=negocio.antelacion_maxima_dias,
        )

        lineas = []

        for item in datos.servicios:
            servicio = _servicio_publico(db, item.servicio_id, empleado)

            lineas.append(
                ServicioDeCita(
                    servicio_id=servicio.id,
                    precio_unitario=servicio.precio,
                    duracion_minutos=servicio.duracion_minutos,
                    cantidad=item.cantidad,
                )
            )

        hora_fin = calcular_hora_fin(
            datos.fecha, datos.hora_inicio, duracion_servicios_minutos(lineas)
        )

        cliente = _cliente_para_reserva(db, negocio, datos.nombre, datos.telefono)

        # Límites por cliente (se cuentan en la base, así valen aunque cambie la IP)
        recientes = db.execute(
            select(func.count()).select_from(Cita).where(
                Cita.cliente_id == cliente.id,
                Cita.origen == "CLIENTE",
                Cita.fecha_creacion >= hace_una_hora,
            )
        ).scalar()

        if recientes >= LIMITE_RESERVAS_CLIENTE_HORA:
            raise HTTPException(
                status_code=429,
                detail="Hiciste muchas reservas seguidas. Intenta de nuevo más tarde",
                headers={"Retry-After": "3600"},
            )

        activas = len(citas_futuras_activas(db, cliente_id=cliente.id))

        if activas >= negocio.max_reservas_activas_cliente:
            raise HTTPException(
                status_code=409,
                detail=(
                    f"Ya tienes {activas} reserva(s) activa(s), que es el máximo permitido. "
                    "Cancela alguna o comunícate con el negocio"
                ),
            )

        _genericar_409(
            "Esa hora ya no está disponible. Elige otra",
            validar_disponibilidad, db, empleado.id, datos.fecha, datos.hora_inicio, hora_fin,
        )
        _genericar_409(
            "Ya tienes una reserva en ese horario",
            validar_cliente_sin_solape, db, cliente.id, datos.fecha, datos.hora_inicio, hora_fin,
        )

        nueva_cita = Cita(
            negocio_id=negocio.id,
            cliente_id=cliente.id,
            usuario_negocio_id=empleado.id,
            fecha=datos.fecha,
            hora_inicio=datos.hora_inicio,
            hora_fin=hora_fin,
            estado="PENDIENTE",
            origen="CLIENTE",
            observaciones=datos.observaciones,
            codigo_publico=generar_codigo(),
        )
        nueva_cita.servicios = lineas

        db.add(nueva_cita)
        db.commit()
        db.refresh(nueva_cita)

        return {
            "mensaje": "Reserva creada. Guarda tu código para consultarla o cancelarla",
            "enlace": enlace_reserva(nueva_cita.codigo_publico),
            **_detalle_reserva(nueva_cita, negocio, ahora),
        }

    finally:
        db.close()


# ---------------------------------------------------------------------------
# Gestionar una reserva con su código
# ---------------------------------------------------------------------------
def _cita_por_codigo(db, request: Request, codigo: str, bloquear: bool = False):
    exigir_limite(request, "codigo", LIMITE_CODIGO_IP, VENTANA_SEGUNDOS)
    exigir_sin_fallos(request, "codigo", LIMITE_FALLOS_CODIGO_IP, VENTANA_SEGUNDOS)

    normalizado = normalizar_codigo(codigo)
    cita = None

    if normalizado:
        consulta = select(Cita).where(Cita.codigo_publico == normalizado)

        if bloquear:
            consulta = consulta.with_for_update()

        cita = db.execute(consulta).scalars().first()

    if cita is None:
        registrar_fallo(request, "codigo")
        raise HTTPException(status_code=404, detail="Reserva no encontrada")

    return cita


@router.get("/reservas-publicas/{codigo}")
def consultar_reserva_publica(codigo: str, request: Request, response: Response):
    _sin_cache(response)
    db = SessionLocal()

    try:
        cita = _cita_por_codigo(db, request, codigo)
        negocio = db.get(Negocio, cita.negocio_id)

        return _detalle_reserva(cita, negocio, datetime.now())

    finally:
        db.close()


@router.post("/reservas-publicas/{codigo}/confirmar")
def confirmar_reserva_publica(codigo: str, request: Request, response: Response):
    _sin_cache(response)
    db = SessionLocal()

    try:
        # Se bloquea la cita: si el negocio la cancela al mismo tiempo, una de las dos
        # operaciones espera a la otra y ve el estado final.
        cita = _cita_por_codigo(db, request, codigo, bloquear=True)
        negocio = db.get(Negocio, cita.negocio_id)
        ahora = datetime.now()
        inicio = datetime.combine(cita.fecha, cita.hora_inicio)

        if cita.estado == "CONFIRMADA":
            return {"mensaje": "Tu reserva ya estaba confirmada", **_detalle_reserva(cita, negocio, ahora)}

        if cita.estado != "PENDIENTE":
            raise HTTPException(
                status_code=409,
                detail=f"Esta reserva está {ESTADO_TEXTO.get(cita.estado, cita.estado)} y ya no se puede confirmar",
            )

        if inicio <= ahora:
            raise HTTPException(status_code=409, detail="La cita ya empezó")

        # La confirmación se abre cuando llega el recordatorio (horas_confirmacion antes).
        # Así quien reserva no puede "confirmarse" a sí mismo en el mismo instante.
        desde = _confirmar_desde(negocio, inicio)

        if desde is not None and ahora < desde:
            raise HTTPException(
                status_code=409,
                detail=f"Todavía no puedes confirmar: podrás hacerlo desde el {desde:%d/%m/%Y} a las {desde:%H:%M}",
            )

        cita.estado = "CONFIRMADA"
        cita.fecha_actualizacion = ahora

        db.commit()
        db.refresh(cita)

        return {"mensaje": "Reserva confirmada. ¡Te esperamos!", **_detalle_reserva(cita, negocio, ahora)}

    finally:
        db.close()


@router.post("/reservas-publicas/{codigo}/cancelar")
def cancelar_reserva_publica(codigo: str, request: Request, response: Response):
    _sin_cache(response)
    db = SessionLocal()

    try:
        cita = _cita_por_codigo(db, request, codigo, bloquear=True)
        negocio = db.get(Negocio, cita.negocio_id)
        ahora = datetime.now()
        inicio = datetime.combine(cita.fecha, cita.hora_inicio)

        if cita.estado == "CANCELADA":
            return {"mensaje": "Tu reserva ya estaba cancelada", **_detalle_reserva(cita, negocio, ahora)}

        if cita.estado not in ("PENDIENTE", "CONFIRMADA"):
            raise HTTPException(
                status_code=409,
                detail=f"Esta reserva está {ESTADO_TEXTO.get(cita.estado, cita.estado)} y ya no se puede cancelar",
            )

        if inicio <= ahora:
            raise HTTPException(status_code=409, detail="La cita ya empezó")

        limite = inicio - timedelta(hours=negocio.cancelacion_minima_horas)

        if ahora > limite:
            contacto = f" al {negocio.telefono}" if negocio.telefono else ""
            raise HTTPException(
                status_code=409,
                detail=(
                    f"Ya no puedes cancelar por este medio (el plazo era hasta el "
                    f"{limite:%d/%m/%Y} a las {limite:%H:%M}). "
                    f"Comunícate con {negocio.nombre}{contacto}"
                ),
            )

        cita.estado = "CANCELADA"
        cita.fecha_actualizacion = ahora

        db.commit()
        db.refresh(cita)

        return {"mensaje": "Reserva cancelada", **_detalle_reserva(cita, negocio, ahora)}

    finally:
        db.close()


# ---------------------------------------------------------------------------
# Configuración pública del negocio (solo ADMIN)
# ---------------------------------------------------------------------------
def _config_a_dict(negocio) -> dict:
    return {
        "slug": negocio.slug,
        "enlace_publico": enlace_negocio(negocio.slug) if negocio.slug else None,
        "reservas_publicas_activas": negocio.reservas_publicas_activas,
        "horas_confirmacion": negocio.horas_confirmacion,
        "cancelacion_minima_horas": negocio.cancelacion_minima_horas,
        "max_reservas_activas_cliente": negocio.max_reservas_activas_cliente,
        "antelacion_minima_minutos": negocio.antelacion_minima_minutos,
        "antelacion_maxima_dias": negocio.antelacion_maxima_dias,
    }


@router.get("/configuracion/publica")
def obtener_configuracion_publica(ctx: Contexto = Depends(solo_admin)):
    db = SessionLocal()

    try:
        negocio = obtener_o_404(db, Negocio, ctx.negocio_id, "Negocio no encontrado")

        return _config_a_dict(negocio)

    finally:
        db.close()


@router.put("/configuracion/publica")
def actualizar_configuracion_publica(
    datos: schemas.ConfiguracionPublica, ctx: Contexto = Depends(solo_admin)
):
    db = SessionLocal()

    try:
        negocio = obtener_o_404(
            db, Negocio, ctx.negocio_id, "Negocio no encontrado", bloquear=True
        )

        if datos.reservas_publicas_activas and not datos.slug:
            raise HTTPException(
                status_code=400,
                detail="Define un enlace (slug) antes de activar las reservas públicas",
            )

        if datos.slug:
            ocupado = db.execute(
                select(Negocio.id).where(Negocio.slug == datos.slug, Negocio.id != negocio.id)
            ).first()

            if ocupado is not None:
                raise HTTPException(status_code=409, detail="Ese enlace ya está en uso, elige otro")

        negocio.slug = datos.slug
        negocio.reservas_publicas_activas = datos.reservas_publicas_activas
        negocio.horas_confirmacion = datos.horas_confirmacion
        negocio.cancelacion_minima_horas = datos.cancelacion_minima_horas
        negocio.max_reservas_activas_cliente = datos.max_reservas_activas_cliente
        negocio.antelacion_minima_minutos = datos.antelacion_minima_minutos
        negocio.antelacion_maxima_dias = datos.antelacion_maxima_dias

        db.commit()
        db.refresh(negocio)

        return {"mensaje": "Configuración actualizada correctamente", **_config_a_dict(negocio)}

    finally:
        db.close()
