"""
Worker de recordatorios: confirma citas por WhatsApp.

Se ejecuta APARTE del servidor web, en su propia terminal (con el venv activado):

    python worker.py                  # se queda corriendo y revisa cada 60 segundos
    python worker.py --una-vez        # una sola pasada (para probar o para un cron)
    python worker.py --intervalo 30

Por defecto usa el proveedor "consola" (no envía nada, solo muestra el mensaje).
Para enviar de verdad por WhatsApp ver notificaciones.py.
Se pueden tener varios workers a la vez sin que se dupliquen los mensajes.
"""
import argparse
import logging
import time

import notificaciones
from database import SessionLocal

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger("valen.worker")


def una_pasada(proveedor):
    db = SessionLocal()

    try:
        creadas = notificaciones.programar_confirmaciones(db)
        enviadas = notificaciones.enviar_pendientes(db, proveedor)

        if creadas or enviadas:
            logger.info("Confirmaciones programadas: %s, enviadas: %s", creadas, enviadas)
    finally:
        db.close()


def main():
    parser = argparse.ArgumentParser(description="Worker de recordatorios de Valen")
    parser.add_argument("--una-vez", action="store_true", help="hace una sola pasada y termina")
    parser.add_argument("--intervalo", type=int, default=60, help="segundos entre pasadas")
    argumentos = parser.parse_args()

    proveedor = notificaciones.proveedor_por_defecto()
    logger.info("Worker iniciado con proveedor %s", type(proveedor).__name__)

    if argumentos.una_vez:
        una_pasada(proveedor)
        return

    while True:
        try:
            una_pasada(proveedor)
        except Exception:
            # Un fallo (por ejemplo, la base de datos caída un momento) no debe matar el worker
            logger.exception("Error en la pasada; se reintenta en %s s", argumentos.intervalo)

        time.sleep(argumentos.intervalo)


if __name__ == "__main__":
    main()
