"""
Recordatorios por WhatsApp para confirmar citas.

Cómo funciona (en dos pasos, que ejecuta worker.py cada minuto):

  1. programar_confirmaciones: busca citas PENDIENTES cuyo negocio tiene
     `horas_confirmacion` y a las que ya les llegó esa ventana (por ejemplo, 24 h antes
     de la cita). Por cada una crea UNA fila en la tabla `notificacion`. La restricción
     UNIQUE (cita_id, tipo) garantiza que nunca se pida dos veces la confirmación de
     la misma cita, aunque haya varios workers.

  2. enviar_pendientes: toma las filas PENDIENTES y las manda con el proveedor
     configurado. Si el envío falla se reintenta con espera creciente (5, 10, 20 min) y,
     tras MAX_INTENTOS, queda FALLIDA. Si mientras tanto la cita ya se confirmó, se
     canceló o empezó, la notificación se marca OMITIDA y no se envía.

El mensaje lleva un enlace con el código privado de la reserva. El cliente lo abre,
ve su cita y la confirma (o cancela). El negocio también puede confirmarla en
cualquier momento con PATCH /citas/{id}/confirmar.

Proveedores (variable VALEN_WHATSAPP_PROVEEDOR):
  consola  (por defecto) no envía nada: escribe el mensaje en el log. Para desarrollo.
  cloud    WhatsApp Cloud API de Meta. Requiere una plantilla APROBADA por Meta,
           porque el negocio escribe primero (fuera de la ventana de 24 h de
           conversación solo se permiten plantillas). Variables de entorno:
             VALEN_WHATSAPP_TOKEN        token de acceso permanente
             VALEN_WHATSAPP_PHONE_ID     id del número de WhatsApp Business
             VALEN_WHATSAPP_PLANTILLA    nombre de la plantilla aprobada
             VALEN_WHATSAPP_API_VERSION  versión de la Graph API (consulta la vigente en
                                         la documentación de Meta, ej. v23.0)
             VALEN_WHATSAPP_IDIOMA       opcional, por defecto "es"
  La plantilla debe tener 4 variables en el cuerpo, en este orden:
     {{1}} nombre del cliente, {{2}} negocio, {{3}} cuándo, {{4}} enlace.
  Ejemplo de texto:
     "Hola {{1}}, te recordamos tu cita en {{2}} el {{3}}. Para confirmarla o
      cancelarla entra a este enlace: {{4}} ¡Te esperamos!"

Números: se guardan como los escribió el cliente (ej. 3101234567). Para WhatsApp se les
antepone el indicativo de VALEN_PAIS_TELEFONO (por defecto 57) si tienen 10 dígitos y
no empiezan con "+".
"""
import json
import logging
import os
import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from urllib import error, request

from sqlalchemy import exists, select
from sqlalchemy.exc import IntegrityError

from codigos import enlace_reserva, generar_codigo
from models import Cita, Cliente, Negocio, Notificacion

logger = logging.getLogger("valen.notificaciones")

TIPO_CONFIRMACION = "CONFIRMACION"
MAX_INTENTOS = 4

# horas_confirmacion llega como máximo a 168 h (7 días): no hace falta mirar más lejos
DIAS_DE_BUSQUEDA = 8

DIAS = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]
MESES = [
    "enero", "febrero", "marzo", "abril", "mayo", "junio",
    "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre",
]


# ---------------------------------------------------------------------------
# Mensaje y proveedores
# ---------------------------------------------------------------------------
@dataclass
class MensajeConfirmacion:
    telefono: str   # solo dígitos, con indicativo de país
    cliente: str
    negocio: str
    cuando: str     # "lunes 2 de noviembre a las 10:00"
    enlace: str


class ErrorDeEnvio(Exception):
    pass


def a_numero_whatsapp(telefono: str) -> str:
    solo = re.sub(r"\D", "", telefono)

    if telefono.strip().startswith("+"):
        return solo

    pais = os.getenv("VALEN_PAIS_TELEFONO", "57")

    if pais and len(solo) == 10:
        return pais + solo

    return solo


def _limpiar_parametro(texto: str) -> str:
    # Los parámetros de plantilla no admiten saltos de línea ni tabulaciones
    return re.sub(r"\s+", " ", texto).strip()[:200]


class ProveedorConsola:
    """No envía nada: deja el mensaje en el log. Para probar sin cuenta de WhatsApp."""

    def enviar_confirmacion(self, m: MensajeConfirmacion) -> str:
        logger.info(
            "[WhatsApp SIMULADO] a %s: Hola %s, te recordamos tu cita en %s el %s. "
            "Confírmala o cancélala aquí: %s",
            m.telefono, m.cliente, m.negocio, m.cuando, m.enlace,
        )
        return "consola"


class ProveedorWhatsAppCloud:
    def __init__(self):
        requeridas = (
            "VALEN_WHATSAPP_TOKEN",
            "VALEN_WHATSAPP_PHONE_ID",
            "VALEN_WHATSAPP_PLANTILLA",
            "VALEN_WHATSAPP_API_VERSION",
        )
        faltan = [n for n in requeridas if not os.getenv(n)]

        if faltan:
            raise RuntimeError("Faltan variables de entorno para WhatsApp: " + ", ".join(faltan))

        self.token = os.environ["VALEN_WHATSAPP_TOKEN"]
        self.plantilla = os.environ["VALEN_WHATSAPP_PLANTILLA"]
        self.idioma = os.getenv("VALEN_WHATSAPP_IDIOMA", "es")
        self.url = (
            f"https://graph.facebook.com/{os.environ['VALEN_WHATSAPP_API_VERSION']}"
            f"/{os.environ['VALEN_WHATSAPP_PHONE_ID']}/messages"
        )

    def enviar_confirmacion(self, m: MensajeConfirmacion) -> str:
        cuerpo = {
            "messaging_product": "whatsapp",
            "to": m.telefono,
            "type": "template",
            "template": {
                "name": self.plantilla,
                "language": {"code": self.idioma},
                "components": [
                    {
                        "type": "body",
                        "parameters": [
                            {"type": "text", "text": _limpiar_parametro(valor)}
                            for valor in (m.cliente, m.negocio, m.cuando, m.enlace)
                        ],
                    }
                ],
            },
        }

        peticion = request.Request(
            self.url,
            data=json.dumps(cuerpo).encode("utf-8"),
            method="POST",
            headers={
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json",
            },
        )

        try:
            with request.urlopen(peticion, timeout=15) as respuesta:
                datos = json.loads(respuesta.read())
            return datos["messages"][0]["id"]
        except error.HTTPError as e:
            raise ErrorDeEnvio(f"WhatsApp respondió {e.code}: {e.read().decode('utf-8', 'replace')[:300]}")
        except (error.URLError, TimeoutError) as e:
            raise ErrorDeEnvio(f"No se pudo contactar a WhatsApp: {e}")
        except (KeyError, IndexError, ValueError) as e:
            raise ErrorDeEnvio(f"Respuesta inesperada de WhatsApp: {e}")


def proveedor_por_defecto():
    nombre = os.getenv("VALEN_WHATSAPP_PROVEEDOR", "consola").lower()

    if nombre == "consola":
        return ProveedorConsola()

    if nombre == "cloud":
        return ProveedorWhatsAppCloud()

    raise RuntimeError("VALEN_WHATSAPP_PROVEEDOR debe ser 'consola' o 'cloud'")


# ---------------------------------------------------------------------------
# Paso 1: crear las notificaciones que ya toca enviar
# ---------------------------------------------------------------------------
def programar_confirmaciones(db, ahora: datetime | None = None) -> int:
    ahora = ahora or datetime.now()
    hoy = ahora.date()

    filas = db.execute(
        select(Cita, Negocio)
        .join(Negocio, Negocio.id == Cita.negocio_id)
        .where(
            Cita.estado == "PENDIENTE",
            Cita.fecha >= hoy,
            Cita.fecha <= hoy + timedelta(days=DIAS_DE_BUSQUEDA),
            Negocio.horas_confirmacion.is_not(None),
            ~exists().where(
                Notificacion.cita_id == Cita.id,
                Notificacion.tipo == TIPO_CONFIRMACION,
            ),
        )
        .order_by(Cita.fecha, Cita.hora_inicio)
        .limit(500)
    ).all()

    creadas = 0

    for cita, negocio in filas:
        inicio = datetime.combine(cita.fecha, cita.hora_inicio)

        if inicio <= ahora:
            continue

        if ahora < inicio - timedelta(hours=negocio.horas_confirmacion):
            continue  # todavía no abre la ventana de confirmación

        try:
            # Savepoint: si otro worker se adelantó (UNIQUE), solo se descarta esta fila
            with db.begin_nested():
                if not cita.codigo_publico:
                    cita.codigo_publico = generar_codigo()

                db.add(
                    Notificacion(
                        negocio_id=negocio.id,
                        cita_id=cita.id,
                        tipo=TIPO_CONFIRMACION,
                        proximo_intento=ahora,
                    )
                )
                db.flush()

            creadas += 1
        except IntegrityError:
            logger.info("Cita %s: la confirmación ya estaba programada", cita.id)

    db.commit()

    return creadas


# ---------------------------------------------------------------------------
# Paso 2: enviar las pendientes
# ---------------------------------------------------------------------------
def _cuando(cita) -> str:
    f = cita.fecha
    return f"{DIAS[f.weekday()]} {f.day} de {MESES[f.month - 1]} a las {cita.hora_inicio:%H:%M}"


def _procesar(db, n: Notificacion, proveedor, ahora: datetime) -> bool:
    cita = db.get(Cita, n.cita_id)

    if (
        cita is None
        or cita.estado != "PENDIENTE"
        or datetime.combine(cita.fecha, cita.hora_inicio) <= ahora
    ):
        n.estado = "OMITIDA"
        return False

    negocio = db.get(Negocio, n.negocio_id)
    cliente = db.get(Cliente, cita.cliente_id)

    if not cita.codigo_publico:
        cita.codigo_publico = generar_codigo()

    try:
        n.proveedor_id = proveedor.enviar_confirmacion(
            MensajeConfirmacion(
                telefono=a_numero_whatsapp(cliente.telefono),
                cliente=cliente.nombre.split()[0] if cliente.nombre.strip() else "cliente",
                negocio=negocio.nombre,
                cuando=_cuando(cita),
                enlace=enlace_reserva(cita.codigo_publico),
            )
        )
    except Exception as exc:
        n.intentos += 1
        n.ultimo_error = str(exc)[:500]

        if n.intentos >= MAX_INTENTOS:
            n.estado = "FALLIDA"
        else:
            n.proximo_intento = ahora + timedelta(minutes=5 * 2 ** (n.intentos - 1))

        logger.warning(
            "Notificación %s (cita %s): intento %s fallido: %s",
            n.id, n.cita_id, n.intentos, exc,
        )
        return False

    n.estado = "ENVIADA"
    n.fecha_envio = datetime.now()

    return True


def enviar_pendientes(db, proveedor, ahora: datetime | None = None, limite: int = 50) -> int:
    """Envía hasta `limite` notificaciones. Devuelve cuántas salieron bien."""
    ahora = ahora or datetime.now()
    enviadas = 0

    for _ in range(limite):
        # Una a una y con SKIP LOCKED: dos workers nunca toman la misma fila
        n = db.execute(
            select(Notificacion)
            .where(
                Notificacion.estado == "PENDIENTE",
                Notificacion.proximo_intento <= ahora,
            )
            .order_by(Notificacion.proximo_intento, Notificacion.id)
            .limit(1)
            .with_for_update(skip_locked=True)
        ).scalars().first()

        if n is None:
            break

        if _procesar(db, n, proveedor, ahora):
            enviadas += 1

        db.commit()

    return enviadas
